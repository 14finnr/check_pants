import tkinter as tk
from tkinter import ttk
import files.modules.fileroutes as fileroutes
import files.modules.values as values

items_statue=['floor','wall','walls','ceiling','statue']

def choice_statue(b,c,d):

    if d in items_statue+values.inventory_lower:

        if c in ('check','examine','inspect','search'):

            if d in ('wall','walls','ceiling'):
                b.insert(tk.END, "You "+c+" the "+d+" and find nothing of significance.")

            if d=='floor':
                items_statue.remove('floor')
                items_statue.append('jewel')
                b.insert(tk.END, "Upon "+c+"ing the floor, you spy a beautiful little jewel near the base of the statue.")

            if d=='statue':
                add_dict = {1: " In it's left eye is a shiny jewel.",
                            2: " In it's bottom two eyes are a pair of shiny jewels.",
                            3: " In it's three eye sockets are shiny jewels."}
                b.insert(tk.END, "The statue looks human, yet with all the wrong proportions. It's figure is clearly male"+
                         " yet oddly feminine, and you cannot tell whether it is sitting or kneeling.")
                if values.statue_jewels>0:
                    b.insert(tk.END, add_dict[values.statue_jewels])

        if c in ('take','grab','get') and d=='jewel':
            try:
                items_statue.remove('jewel')
                b.insert(tk.END, "Taken.")
                values.inventory_lower.append('jewel')
                values.inventory.append('Jewel')
            except ValueError:
                pass

    if c in ('use','put','place') and d in ('jewel','jewels'):
        if 'jewel' not in values.inventory_lower and values.statue_jewels==0:
            b.insert(tk.END, "A good idea perhaps, but you lack any jewels.")
