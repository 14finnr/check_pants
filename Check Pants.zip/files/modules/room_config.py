import tkinter as tk
from tkinter import ttk
import collections
import files.modules.fileroutes as fileroutes
import files.modules.values as values
import files.modules.choice_basement as choice_basement
from files.modules.death import die_noframe

def room_configure(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):
   
    #label, image_label, inventory_label, health_bar, button_top,
    #button_left, button_right, button_bottom,
    #textbox, button_look, entrybox, prompt, minimap_label, player_icon, enemy_label
    
    for z in values.inventory_lower:
        if values.inventory.count(str.capitalize(z))>=1 and values.inventory_lower.count(z)>1:
            values.inventory.append(str.capitalize(z)+' x'+str(values.inventory_lower.count(z)))
            while values.inventory.count(str.capitalize(z))>0:
                values.inventory.remove(str.capitalize(z))
    if 'Note x2' in values.inventory:
        values.inventory.remove('Note x2')
        values.inventory.append('Note')
    
    health_image=tk.PhotoImage(file=values.health_bar[values.health])
    c.configure(text=values.inventory_func)
    d.configure(image=health_image)
    d.image=health_image

    def button_push(p,n,o):

        values.direction(p,n,o)
        room_configure(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r)

    def room_one(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        if values.door1==[]:
            
            photo=tk.PhotoImage(file=fileroutes.room1_image)
        else:
            photo=tk.PhotoImage(file=fileroutes.open_door)
            if max(values.minimap_counter)==1:
                minimap_photo=tk.PhotoImage(file=fileroutes.minimap_room1_nodoor)
                m.configure(image=minimap_photo)
                m.image=minimap_photo

        icon = tk.PhotoImage(file=fileroutes.player_icon)
        a.configure(text='Small Room')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='North', command=lambda: button_push(i,'n',' '))
        f.configure(text='West', command=lambda: button_push(i,'w',' '))
        g.configure(text='East', command=lambda: button_push(i,'e',' '))
        h.configure(text='South', command=lambda: button_push(i,'s',' '))
        q.configure(image=icon)
        q.image = icon
        q.place(in_=m, x=45, y=90)

    def hallway_middle(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        icon=tk.PhotoImage(file=fileroutes.player_icon)
        photo=tk.PhotoImage(file=fileroutes.hall_image_middle)
        a.configure(text='Hallway')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='North', command=lambda: button_push(i,'n',' '))
        f.configure(text='Look\nWest', command=lambda: button_push(i,'w',' '))
        g.configure(text='Look\nEast', command=lambda: button_push(i,'e',' '))
        h.configure(text='South', command=lambda: button_push(i,'s',' '))
        if max(values.minimap_counter)==2:
            minimap_photo=tk.PhotoImage(file=fileroutes.minimap_hallway)
            m.configure(image=minimap_photo)
            m.photo=minimap_photo
        q.configure(image=icon)
        q.image=icon
        q.place(in_=m, x=45, y=75)

    def hallway_left(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        icon_left=tk.PhotoImage(file=fileroutes.player_icon_left)
        photo=tk.PhotoImage(file=fileroutes.hall_image_left)
        b.configure(image=photo)
        b.image=photo
        e.configure(text='West', command=lambda: button_push(i,'w',' '))
        f.configure(text='South', command=lambda: button_push(i,'s',' '))
        g.configure(text='North', command=lambda: button_push(i,'n',' '))
        h.configure(text='Look\nEast', command=lambda: button_push(i,'e',' '))
        q.configure(image=icon_left)
        q.image=icon_left
        q.place(in_=m, x=45, y=75)

    def hallway_right(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.hall_image_right)
        b.configure(image=photo)
        b.image=photo
        e.configure(text='East', command=lambda: button_push(i,'e',' '))
        f.configure(text='North', command=lambda: button_push(i,'n',' '))
        g.configure(text='South', command=lambda: button_push(i,'s',' '))
        h.configure(text='Look\nWest', command=lambda: button_push(i,'w',' '))
        icon_right = tk.PhotoImage(file=fileroutes.player_icon_right)
        q.configure(image=icon_right)
        q.image = icon_right
        q.place(in_=m, x=45, y=75)

    def westhall(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.westhall_image)
        a.configure(text='West Hall')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='West', command=lambda: button_push(i,'w',' '))
        f.configure(text='South', command=lambda: button_push(i,'s',' '))
        g.configure(text='North', command=lambda: button_push(i,'n',' '))
        h.configure(text='East', command=lambda: button_push(i,'e',' '))
        if max(values.minimap_counter)==3:
            minimap_photo=tk.PhotoImage(file=fileroutes.minimap_westhall_only)
            m.configure(image=minimap_photo)
            m.image=minimap_photo
        elif max(values.minimap_counter)==4:
            if values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_westhall)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_westhall_opendoor)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        elif max(values.minimap_counter)==5:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_river)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        elif max(values.minimap_counter) == 6:
            if values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms_door)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        icon=tk.PhotoImage(file=fileroutes.player_icon_left)
        q.configure(image=icon)
        q.image=icon
        q.place(in_=m, x=15, y=74)

    def easthallmonster(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo_dict={True:fileroutes.easthall_monster_image, False:fileroutes.easthall_monster_nodoor_image}
        photo=tk.PhotoImage(file=photo_dict[values.door_easthall])
        a.configure(text='East Hall')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='North', command=lambda: button_push(i,'n',' '))
        f.configure(text='West', command=lambda: button_push(i,'w',' '))
        g.configure(text='East', command=lambda: button_push(i,'e',' '))
        h.configure(text='South', command=lambda: button_push(i,'s',' '))
        if max(values.minimap_counter)==3:
            minimap_photo=tk.PhotoImage(file=fileroutes.minimap_easthall_only)
            m.configure(image=minimap_photo)
            m.image=minimap_photo
        elif max(values.minimap_counter)==4:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_westhall)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        elif max(values.minimap_counter)==5:
            if not values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_river)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        elif max(values.minimap_counter) == 6:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        #copy_photo=tk.PhotoImage(file=fileroutes.enemy_icon)
        #copy=tk.Label(m, image=copy_photo, bd=0)
        #copy.image=copy_photo
        icon=tk.PhotoImage(file=fileroutes.player_icon)
        q.configure(image=icon)
        q.image=icon
        q.place(in_=m, x=85, y=70)
        r.place(in_=m, x=86, y=55)
        #copy.place(in_=m, x=50, y=50)

    def easthall(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo_dict={'torch_open':fileroutes.easthall_open_torch_image, 'notorch_open':fileroutes.easthall_open_notorch_image,
                    'lit':fileroutes.easthall_torch_image, 'unlit':fileroutes.easthall_image, 'taken':fileroutes.easthall_image}
        photo=tk.PhotoImage(file=photo_dict[values.torch[0]])
        a.configure(text='East Hall')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='North', command=lambda: button_push(i,'n',' '))
        f.configure(text='West', command=lambda: button_push(i,'w',' '))
        g.configure(text='East', command=lambda: button_push(i,'e',' '))
        h.configure(text='South', command=lambda: button_push(i,'s',' '))
        if max(values.minimap_counter) == 3:
            if not values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_opendoor)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_only)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        elif max(values.minimap_counter) == 4:
            if values.sound!='present':
                if not values.door_easthall :
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_westhall_opendoor)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
                else:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_westhall)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_guardroom_easthall)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        elif max(values.minimap_counter) == 5:
            if values.sound!='present':
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_river)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_easthall)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        elif max(values.minimap_counter) == 6:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        icon = tk.PhotoImage(file=fileroutes.player_icon)
        q.configure(image=icon)
        q.image = icon
        q.place(in_=m, x=85, y=70)
        r.place_forget()

    def basement(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.basement_image)
        a.configure(text='Basement')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='East', command=lambda: button_push(i,'e',' '))
        f.configure(text='North', command=lambda: button_push(i,'n',' '))
        g.configure(text='South', command=lambda: button_push(i,'s',' '))
        h.configure(text='West', command=lambda: button_push(i,'w',' '))
        minimap_photo=tk.PhotoImage(file=fileroutes.minimap_sewer)
        m.configure(image=minimap_photo)
        m.image=minimap_photo
        icon_photo=tk.PhotoImage(file=fileroutes.player_icon_right)
        q.configure(image=icon_photo)
        q.image=icon_photo
        q.place(in_=m, x=20, y=30)

    def backhall(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo_dict={'alive':fileroutes.backroom_image, 'gone':fileroutes.backroom_noman_image, 'dead':fileroutes.backroom_deadman_image}
        photo=tk.PhotoImage(file=photo_dict[values.big_man[0]])
        a.configure(text='Hallway')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='West', command=lambda: button_push(i, 'w', ' '))
        f.configure(text='South', command=lambda: button_push(i, 's', ' '))
        g.configure(text='North', command=lambda: button_push(i, 'n', ' '))
        h.configure(text='East', command=lambda: button_push(i,'e',' '))
        if max(values.minimap_counter)==5:
            if values.sound=='present':
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_easthall)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                if values.door_easthall:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_westhall)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
                else:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_westhall_opendoor)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
        elif max(values.minimap_counter)==6:
            if values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms_door)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
        icon_photo = tk.PhotoImage(file=fileroutes.player_icon_left)
        q.configure(image=icon_photo)
        q.image = icon_photo
        q.place(in_=m, x=43, y=22)
#South tunnel + cultist ending had to be a room configuration instead of a new frame because the 'direction' function can't directly
#interact with the 'window' class.

    def guardroom(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo_dict={'closed':fileroutes.guardroom_image, 'open':fileroutes.guardroom_dooropen_image, 'noguard':fileroutes.guardroom_noguard_image, 'noguardnodoor':fileroutes.guardroom_nodoor_noguard_image}
        photo=tk.PhotoImage(file=photo_dict[values.door_guardroom[0]])
        a.configure(text='Guard Room')
        b.configure(image=photo)
        b.image=photo
        e.configure(text="West", command=lambda: button_push(i,'w',' '))
        f.configure(text="South", command=lambda: button_push(i,'s',' '))
        g.configure(text="North", command=lambda: button_push(i,'n',' '))
        h.configure(text="East", command=lambda: button_push(i,'e',' '))
        if max(values.minimap_counter)==4:
            if values.door_easthall and values.monster:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_river)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                if values.monster:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_river_opendoor)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
                    r.place(in_=m, x=86, y=55)
                else:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_guardroom_easthall)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
        if max(values.minimap_counter)==5:
            if values.sound!='present' and not values.monster:
                if values.door_easthall:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_river_door)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
                else:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_easthall_river)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
            else:
                if values.sound!='present':
                    if values.door_easthall:
                        minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_westhall)
                        m.configure(image=minimap_photo)
                        m.image = minimap_photo
                    else:
                        minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_westhall_opendoor)
                        m.configure(image=minimap_photo)
                        m.image = minimap_photo
                else:
                    minimap_photo = tk.PhotoImage(file=fileroutes.minimap_backroom_easthall)
                    m.configure(image=minimap_photo)
                    m.image = minimap_photo
        if max(values.minimap_counter)==6:
            if values.door_easthall:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms_door)
                m.configure(image=minimap_photo)
                m.image = minimap_photo
            else:
                minimap_photo = tk.PhotoImage(file=fileroutes.minimap_allrooms)
                m.configure(image=minimap_photo)
                m.image = minimap_photo

        icon_photo = tk.PhotoImage(file=fileroutes.player_icon_left)
        q.configure(image=icon_photo)
        q.image = icon_photo
        q.place(in_=m, x=85, y=25)

    def uphall_middle(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.hall_image_middle)
        a.configure(text='Hallway')
        b.configure(image=photo)
        b.image=photo
        e.configure(text='West', command=lambda: button_push(i,'w',' '))
        f.configure(text='Look\nSouth', command=lambda: button_push(i,'s',' '))
        g.configure(text='Look\nNorth', command=lambda: button_push(i,'n',' '))
        h.configure(text='East', command=lambda: button_push(i, 'e', ' '))
        if max(values.minimap_counter_two)==0:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_upstairs)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        else:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_statue)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        icon_photo = tk.PhotoImage(file=fileroutes.player_icon_left)
        q.configure(image=icon_photo)
        q.image = icon_photo
        q.place(in_=m, x=45, y=40)

    def uphall_right(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.uphall_right_image)
        b.configure(image=photo)
        b.image=photo
        e.configure(text='North', command=lambda: button_push(i, 'n', ' '))
        f.configure(text='West', command=lambda: button_push(i, 'w', ' '))
        g.configure(text='East', command=lambda: button_push(i, 'e', ' '))
        h.configure(text='Look\nSouth', command=lambda: button_push(i,'s',' '))
        icon_photo = tk.PhotoImage(file=fileroutes.player_icon)
        q.configure(image=icon_photo)
        q.image = icon_photo

    def uphall_left(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        photo=tk.PhotoImage(file=fileroutes.hall_image_left)
        b.configure(image=photo)
        b.image=photo
        e.configure(text='South', command=lambda: button_push(i,'s',' '))
        f.configure(text='East', command=lambda: button_push(i,'e',' '))
        g.configure(text='West', command=lambda: button_push(i,'w',' '))
        h.configure(text='Look\nNorth', command=lambda: button_push(i,'n',' '))
        icon_photo = tk.PhotoImage(file=fileroutes.player_icon_down)
        q.configure(image=icon_photo)
        q.image = icon_photo

    def statue_room(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        a.configure(text='Dark Room')
        photo_dict={0:fileroutes.statue_0_image, 1:fileroutes.statue_1_image, 2:fileroutes.statue_2_image,
                    3:fileroutes.statue_3_image}
        photo=tk.PhotoImage(file=photo_dict[values.statue_jewels])
        b.configure(image=photo)
        b.image=photo
        e.configure(text='South', command=lambda: button_push(i,'s',' '))
        f.configure(text='East', command=lambda: button_push(i, 'e', ' '))
        g.configure(text='West', command=lambda: button_push(i, 'w', ' '))
        h.configure(text='North', command=lambda: button_push(i,'n',' '))
        if max(values.minimap_counter_two)==1:
            minimap_photo = tk.PhotoImage(file=fileroutes.minimap_statue)
            m.configure(image=minimap_photo)
            m.image = minimap_photo
        q.place(in_=m, x=45, y=70)

    def south_tunnel(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        def health_change():
            health_image = tk.PhotoImage(file=values.health_bar[values.health])
            d.configure(image=health_image)
            d.image = health_image

        def south_end():

            a.destroy()
            i.configure(height=17)
            i.configure(state='normal')
            values.health=0
            health_change()
            photo=tk.PhotoImage(file=fileroutes.cliff_image)
            b.configure(image=photo)
            b.image=photo
            i.insert(tk.END, "\n\n"+fileroutes.field)
            j.destroy()
            i.see('end')
            i.configure(state='disabled')

        def fight():

            def hands():
                values.health-=3
                health_change()
                i.insert(tk.END, fileroutes.spider_hands)
            def dagger():
                values.health-=2
                health_change()
                i.insert(tk.END, fileroutes.spider_dagger)
            def sword():
                values.health-=1
                health_change()
                i.insert(tk.END, fileroutes.spider_sword)

            fight_dict={0:hands, 1:dagger, 2:dagger, 3:sword}
            i.configure(state='normal')
            photo=tk.PhotoImage(file=fileroutes.south_exit_image)
            b.configure(image=photo)
            b.image=photo
            fight_dict[values.weapons]()
            i.see('end')
            i.configure(state='disabled')
            if values.health>0:
                j.configure(command=lambda: south_end())
            else:
                j.configure(command=lambda: die_noframe(a,b,c,d,e,f,g,h,i,j,k,l))

        def spider():

            values.weapons=0
            for w in values.inventory_lower:
                if w=='dagger':
                    values.weapons+=1
                if w=='sword':
                    values.weapons+=3
            i.configure(state='normal')
            photo=tk.PhotoImage(file=fileroutes.spider_image)
            b.configure(image=photo)
            b.image=photo
            j.configure(command=lambda: fight())
            i.insert(tk.END, fileroutes.spider_attack[134:]+'\n\n')
            i.see('end')
            i.configure(state='disabled')

        photo=tk.PhotoImage(file=fileroutes.south_exit_image)
        a.configure(text=values.location)
        b.configure(image=photo)
        b.image=photo
        for x in (e,f,g,h,k,l,m,q):
            x.destroy()
        j.configure(text='Continue', width=9, command=lambda: spider())

    def cultist(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        def three():

            while values.inventory_lower.count('jewel')>0:
                values.inventory_lower.remove('jewel')
            for thing in values.inventory:
                if 'Jewel x' in thing:
                    values.inventory.remove(thing)
            c.configure(text=values.inventory_func)
            j.destroy()
            i.configure(state='normal')
            i.insert(tk.END, '\n\n' + fileroutes.sacrifice_ending + ' ' + fileroutes.threejewel_ending)
            i.configure(state='disabled')
            i.see('end')

        def two():

            for jewel in range(1,3):
                values.inventory_lower.remove('jewel')
            for thing in values.inventory:
                if 'Jewel x' in thing:
                    values.inventory.remove(thing)
            c.configure(text=values.inventory_func)
            j.destroy()
            i.configure(state='normal')
            i.insert(tk.END, '\n\n' + fileroutes.sacrifice_ending + ' ' + fileroutes.twojewel_ending)
            i.configure(state='disabled')
            i.see('end')

        def one():

            values.inventory_lower.remove('jewel')
            values.inventory.remove('Jewel')
            c.configure(text=values.inventory_func)
            photo=tk.PhotoImage(file=fileroutes.sacrifice_onejewel_image)
            b.configure(image=photo)
            b.image=photo
            j.destroy()
            i.configure(state='normal')
            i.insert(tk.END, '\n\n'+fileroutes.sacrifice_ending+' '+fileroutes.onejewel_ending)
            i.configure(state='disabled')
            i.see('end')

        def none():

            i.configure(state='normal')
            i.insert(tk.END, "\n\nShe then steps forward and unceremoniously pushes you off the edge.\n\n\n\n")
            die_noframe(a,b,c,d,e,f,g,h,i,j,k,l)

        def run():

            values.location='South Tunnel'
            i.configure(state='normal')
            i.insert(tk.END, "\n\n"+fileroutes.spider_attack[0:134])
            i.configure(state='disabled')
            i.see('end')
            south_tunnel(a, b, c, d, e, f, g, h, i, j, k, l)

        def no():

            values.health-=2
            health_image = tk.PhotoImage(file=values.health_bar[values.health])
            d.configure(image=health_image)
            d.image = health_image
            i.configure(state='normal')
            i.insert(tk.END, "\n\nNo\n\n"+fileroutes.cultist_no)
            i.configure(state='disabled')
            i.see('end')
            for w in (f,g):
                w.grid_remove()
            if values.health>0:
                j.configure(text="Continue", width=10, command=lambda: run())
            else:
                j.configure(text="Continue", width=10, command=lambda: die_noframe(a, b, c, d, e, f, g, h, i, j, k, l))
            j.grid()

        def sacrifice():

            end_dict={0:none, 1:one, 2:two, 3:three, 4:three, 5:three, 6:three}
            photo = tk.PhotoImage(file=fileroutes.sacrifice_image)
            b.configure(image=photo)
            b.image = photo
            i.configure(state='normal')
            i.insert(tk.END, "\n\n" + fileroutes.sacrifice[291:])
            i.configure(state='disabled')
            i.see('end')
            j.configure(command=lambda: end_dict[values.inventory_lower.count('jewel')]())

        def yes():

            a.configure(text='Cliff')
            photo = tk.PhotoImage(file=fileroutes.cliff_image)
            b.configure(image=photo)
            b.image = photo
            i.configure(state='normal')
            i.insert(tk.END, "\n\nYes\n\n" + fileroutes.sacrifice[0:291])
            i.configure(state='disabled')
            i.see('end')
            for w in (f,g):
                w.grid_remove()
            j.configure(text="Continue", width=10, command=lambda: sacrifice())
            j.grid()

        photo=tk.PhotoImage(file=fileroutes.cultist_image)
        b.configure(image=photo)
        b.image = photo
        for x in (e,h,k,l):
            x.grid_remove()
        for z in (m,q):
            z.destroy()
        j.grid_remove()
        f.configure(text='Yes', command=lambda: yes())
        g.configure(text='No', command=lambda: no())
        i.configure(state='normal')
        i.insert(tk.END, fileroutes.cultist_conversation)
        i.configure(state='disabled')
        i.see('end')

    def north_exit(a,b,c,d,e,f,g,h,i,j,k,l,m,q,r):

        def cont_two():

            health_photo=tk.PhotoImage(file=fileroutes.health_bar_0)
            d.configure(image=health_photo)
            d.image=health_photo
            a.configure(text='Forest')
            photo=tk.PhotoImage(file=fileroutes.woods_image)
            b.configure(image=photo)
            b.image = photo
            i.configure(state='normal')
            i.insert(tk.END, "\n\n" + fileroutes.valley[602:])
            i.see('end')
            i.configure(state='disabled')
            j.destroy()

        def cont_one():

            a.configure(text='Valley')
            photo=tk.PhotoImage(file=fileroutes.north_exit_image)
            b.configure(image=photo)
            b.image=photo
            i.configure(state='normal')
            i.insert(tk.END, "\n\n"+fileroutes.valley[166:602])
            i.see('end')
            i.configure(state='disabled')
            j.configure(command=lambda: cont_two())

        a.configure(text=values.location)
        for x in (e,f,g,h,k,l,m,q):
            x.destroy()
        j.configure(text='Continue', width=9, command=lambda:cont_one())

    #def riddle_question(a,b,c,d,e,f,g,h,i,j,k,l):

        #photo=tk.PhotoImage(file=fileroutes.statue_3_image)
        #b.configure(image=photo)
        #b.image=photo
        #i.configure(state='normal')
        #i.insert(tk.END, fileroutes.statue_firsttalk)
        #i.see('end')
        #i.configure(state='disabled')
        #for x in (e,f,g,h,k,l):
        #    x.grid_remove()
        #j.configure(text='Continue', command=lambda: values.sequence.append('riddles'))

    room_list={'North Tunnel':north_exit, 'UphallRight':uphall_right, 'UphallLeft':uphall_left, 'UphallMiddle':uphall_middle,
               'Backhall':backhall, 'Guardroom':guardroom, 'Cultist':cultist, 'South Tunnel':south_tunnel, 'Basement':basement,
               'Easthall':easthall, 'EasthallMonster':easthallmonster, 'Westhall':westhall, 'HallwayRight':hallway_right,
               'HallwayLeft':hallway_left, 'Room1':room_one, 'HallwayMiddle':hallway_middle, 'Dark Room':statue_room}
    room_list[values.location](a,b,c,d,e,f,g,h,i,j,k,l,m,q,r)
    m.place(anchor='nw')

    if values.health<=0:
        for w in (e,f,g,h,j):
            w.configure(command=lambda: None)
