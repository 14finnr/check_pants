import tkinter as tk
import files.modules.values as values

def choice_northtunnel(b,c,d):
    pass